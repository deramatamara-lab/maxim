/**
 * Aura Shell
 * Phases implemented here:
 * - Phase 1: Premium shell (hero, GlassView, NeonButton, NoiseOverlay, FloatingTabBar)
 * - Phase 2: Globe background (Globe component)
 * - Phase 3: Globe → Map crossfade (MapContainer)
 * Phase 4+ rider/driver flows live in separate routed screens.
 */
import React, { useRef, useState, useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { StyleSheet, Text, TextInput, View, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { NoiseOverlay } from '../components/ui/NoiseOverlay';
import Animated, { 
  useAnimatedStyle, 
  useSharedValue, 
  withTiming,
  Easing,
  FadeIn, 
  FadeOut,
  runOnUI,
} from 'react-native-reanimated';

import { ds } from '../constants/theme';
import { GlassView } from '../components/ui/GlassView';
import { NeonButton } from '../components/ui/NeonButton';
import { ProfileAvatar } from '../components/ui/ProfileAvatar';
import { Globe, type GlobeHandle } from '../components/3d/Globe';
import { MapContainer, type MapContainerHandle } from '../components/map/MapContainer';
import { useHaptics } from '../hooks/useHaptics';
import { useSound } from '../hooks/useSound';
import { FloatingTabBar, TabId } from '../components/ui/FloatingTabBar';
import { AuraCard } from '../components/ui/AuraCard';

//================================================================
// 1. CONSTANTS & CONFIG
//================================================================
const { width: SHELL_WIDTH, height: SHELL_HEIGHT } = ds.layout.shell;

const AnimatedView = Animated.createAnimatedComponent(View);

type AppState = 'idle' | 'searching' | 'zooming' | 'map' | 'selection';

//================================================================
// 2. SUB-COMPONENTS
//================================================================

interface HomeScreenProps {
  onSearch: (term: string) => void;
  isGeocoding: boolean;
  errorMsg: string | null;
}

const HomeScreen = React.memo<HomeScreenProps>(function HomeScreen({
  onSearch,
  isGeocoding,
  errorMsg
}) {
  const { trigger } = useHaptics();
  const { play } = useSound();
  const [destination, setDestination] = useState('');

  const { t } = useTranslation();

  const telemetryMetrics = useMemo(
    () => [
      { label: t('home.frameIdle'), value: '60 FPS' },
      { label: t('home.audioHaptic'), value: t('home.synced') },
      { label: t('home.sensors'), value: t('home.synced') },
    ],
    [t]
  );

  return (
    <AnimatedView 
      entering={FadeIn.duration(ds.motion.duration.entrance)} 
      exiting={FadeOut.duration(ds.motion.duration.exit)}
      style={styles.contentWrapper}
    >
      <View style={styles.header}>
        <View style={styles.welcomeContainer}>
          <Text style={styles.welcomeText}>{t('home.greeting')}</Text>
          <Text style={styles.nameText}>{t('home.userName', { name: 'Tony Stark' })}</Text>
        </View>
        <ProfileAvatar />
      </View>

      <View style={styles.mainContent}>
        <View style={styles.heroSection}>
          <Text style={styles.heroKicker}>{t('home.heroKicker')}</Text>
          <Text style={styles.heroTitle}>{t('home.heroTitle')}</Text>
          <Text style={styles.heroBody}>{t('home.heroBody')}</Text>
        </View>

        <GlassView 
          style={styles.glassCard}
          elevated
          onPress={() => {
            trigger('selection');
            play('click');
          }}
        >
          <View style={styles.inputRow}>
            <View style={styles.dotOrigin} />
            <Text style={styles.inputText}>{t('home.currentLocation')}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.inputRow}>
            <View style={styles.dotDest} />
            <TextInput
              style={styles.input}
              placeholder={t('home.destinationPlaceholder')}
              placeholderTextColor={ds.colors.textSecondary}
              value={destination}
              onChangeText={setDestination}
            />
          </View>
        </GlassView>

        {errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}

        <NeonButton 
          onPress={() => {
            trigger('selection');
            play('click');
            onSearch(destination);
          }}
          disabled={!destination || isGeocoding}
          loading={isGeocoding}
          style={{ marginTop: ds.spacing.xl }}
        >
          {isGeocoding ? t('home.cta.locating') : t('home.cta.searchRides')}
        </NeonButton>

        <GlassView style={styles.telemetryCard} disableBlur>
          <Text style={styles.telemetryTitle}>{t('home.telemetryTitle')}</Text>
          <View style={styles.telemetryRowGroup}>
            {telemetryMetrics.map(metric => (
              <View key={metric.label} style={styles.telemetryRow}>
                <Text style={styles.telemetryLabel}>{metric.label}</Text>
                <Text style={styles.telemetryValue}>{metric.value}</Text>
              </View>
            ))}
          </View>
        </GlassView>
      </View>
    </AnimatedView>
  );
});

interface RideSelectionScreenProps {
  onConfirm?: () => void;
}

const RideSelectionScreen = React.memo<RideSelectionScreenProps>(function RideSelectionScreen({
  onConfirm
}) {
  const [selected, setSelected] = useState(1);
  const { trigger } = useHaptics();
  const { play } = useSound();

  const options = [
    { id: 1, name: 'Aura Lite', time: '3 min', price: '$12.40', icon: '🚗', tier: 'share' },
    { id: 2, name: 'Aura Prime', time: '5 min', price: '$18.90', icon: '🚘', tier: 'pulse' },
    { id: 3, name: 'Aura Lux', time: '8 min', price: '$28.50', icon: '🚙', tier: 'lux' },
  ];

  const handleSelect = (id: number) => {
    trigger('selection');
    play('click');
    setSelected(id);
  };

  const handleConfirm = () => {
    trigger('success');
    play('power');
    onConfirm?.();
  };

  const selectedOption = options.find(o => o.id === selected);

  return (
    <AnimatedView 
      entering={FadeIn.duration(400).delay(200)}
      style={[styles.contentWrapper, { justifyContent: 'flex-end' }]}
    >
      <View style={styles.bottomSheet}>
        <GlassView style={styles.sheetContent}>
          <View style={styles.dragHandle} />
          <Text style={styles.sheetTitle}>Choose your ride</Text>
          
          <View style={styles.rideList}>
            {options.map((opt) => (
              <AuraCard
                key={opt.id}
                accentColor="primary"
                elevated={selected === opt.id}
                onPress={() => handleSelect(opt.id)}
                style={[
                  styles.rideOption,
                  selected === opt.id && styles.rideOptionSelected
                ]}
              >
                <View style={styles.rideOptionInner}>
                  <Text style={styles.rideIcon}>{opt.icon}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.rideName}>{opt.name}</Text>
                    <Text style={styles.rideTime}>{opt.time} away</Text>
                  </View>
                  <Text style={styles.ridePrice}>{opt.price}</Text>
                </View>
              </AuraCard>
            ))}
          </View>

          <View style={styles.paymentRow}>
            <View style={styles.paymentMethod}>
              <View style={styles.cardIcon} />
              <Text style={styles.paymentText}>Visa •••• 4242</Text>
            </View>
            <Text style={styles.promoText}>Promo</Text>
          </View>

          <NeonButton onPress={handleConfirm} soundEffect="power">
            Confirm {selectedOption?.name}
          </NeonButton>
        </GlassView>
      </View>
    </AnimatedView>
  );
});

const PlaceholderScreen = React.memo<{ title: string }>(function PlaceholderScreen({ title }) {
  return (
    <View style={[styles.contentWrapper, { justifyContent: 'center', alignItems: 'center' }]}>
      <Text style={{ color: ds.colors.textSecondary, fontSize: 20, fontFamily: ds.typography.family }}>
        {title}
      </Text>
    </View>
  );
});

//================================================================
// 3. MAIN APPLICATION
//================================================================

export default function ClientApp() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<TabId>('home');
  const [appState, setAppState] = useState<AppState>('idle');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [coords, setCoords] = useState<{ lat: number; lon: number } | null>(null);
  
  const globeRef = useRef<GlobeHandle>(null);
  const mapRef = useRef<MapContainerHandle>(null);

  // Animation values
  const globeOpacity = useSharedValue(1);
  const mapOpacity = useSharedValue(0);

  const globeStyle = useAnimatedStyle(() => ({
    opacity: globeOpacity.value
  }));

  const mapStyle = useAnimatedStyle(() => ({
    opacity: mapOpacity.value
  }));

  const animateToMap = useCallback(() => {
    const config = {
      duration: ds.motion.duration.crossFade,
      easing: Easing.bezier(0.22, 1, 0.36, 1),
    };
    const animations = () => {
      'worklet';
      globeOpacity.value = withTiming(0, config);
      mapOpacity.value = withTiming(1, config);
    };
    runOnUI(animations)();
  }, [globeOpacity, mapOpacity]);

  const animateToGlobe = useCallback(() => {
    const animations = () => {
      'worklet';
      globeOpacity.value = withTiming(1, {
        duration: ds.motion.duration.entrance,
        easing: Easing.bezier(0.22, 1, 0.36, 1),
      });
      mapOpacity.value = withTiming(0, {
        duration: ds.motion.duration.exit,
        easing: Easing.bezier(0.4, 0, 0.2, 1),
      });
    };
    runOnUI(animations)();
  }, [globeOpacity, mapOpacity]);

  const { trigger } = useHaptics();
  const { play } = useSound();

  const handleSearch = async (term: string) => {
    if (!term) return;
    setAppState('searching');
    setErrorMsg(null);

    try {
      // Simulating API call
      await new Promise(r => setTimeout(r, 1000));
      const lat = 42.6977;
      const lon = 23.3219;
      
      setCoords({ lat, lon });
      setAppState('zooming');
      animateToGlobe();
      
      if (globeRef.current) {
        globeRef.current.zoomToLocation({ lat, lon, radius: 2.1 });
      }
    } catch {
      setErrorMsg(t('home.error.locationNotFound'));
      trigger('error');
      play('click');
      setAppState('idle');
    }
  };

  const handleZoomComplete = useCallback(() => {
    setAppState('map');
    animateToMap();
  }, [animateToMap]);

  const handleMapReady = useCallback(() => {
    // Small delay to ensure map is rendered before showing UI
    setTimeout(() => {
      setAppState('selection');
    }, 800);
  }, []);

  const handleTabChange = useCallback((tab: TabId) => {
    setActiveTab(tab);
    if (tab === 'home') {
      setAppState('idle');
      animateToGlobe();
      setCoords(null);
    }
  }, [animateToGlobe]);

  const renderContent = () => {
    if (appState === 'selection') {
      return <RideSelectionScreen onConfirm={() => {
        setAppState('idle');
        animateToGlobe();
      }} />;
    }

    switch (activeTab) {
      case 'home':
        return <HomeScreen onSearch={handleSearch} isGeocoding={appState === 'searching'} errorMsg={errorMsg} />;
      case 'activity': return <PlaceholderScreen title={t('nav.activity')} />;
      case 'location': return <PlaceholderScreen title={t('nav.locations')} />;
      case 'profile': return <PlaceholderScreen title={t('nav.profile')} />;
      default: return null;
    }
  };

  return (
    <View style={styles.body}>
      <LinearGradient 
        colors={[ds.colors.background, ds.colors.backgroundAlt]} 
        style={StyleSheet.absoluteFill} 
      />
      
      {/* Ambient gradient blobs */}
      <View style={[styles.gradientBlob, styles.topLeftBlob]} />
      <View style={[styles.gradientBlob, styles.bottomRightBlob]} />
      
      {/* Global noise texture */}
      <NoiseOverlay opacity={ds.effects.noiseOpacity} />
      
      <View style={styles.mobileFrame}>
        
        {/* Background Layer: Globe or Map */}
        <View style={styles.backgroundLayer}>
          <AnimatedView style={[StyleSheet.absoluteFill, globeStyle]}>
            <Globe 
              ref={globeRef} 
              onZoomComplete={handleZoomComplete}
              rotationSpeed={0.08}
            />
          </AnimatedView>

          {coords && (
            <AnimatedView style={[StyleSheet.absoluteFill, mapStyle]}>
              <MapContainer 
                ref={mapRef}
                coordinate={[coords.lon, coords.lat]}
                onMapReady={handleMapReady}
              />
            </AnimatedView>
          )}
        </View>

        {/* UI Overlay */}
        <View style={styles.uiLayer}>
          {/* Hide main UI during cinematic zoom */}
          {appState !== 'zooming' && renderContent()}
        </View>

        {/* Bottom Navigation Bar */}
        <View style={styles.navContainer}>
          <FloatingTabBar activeTab={activeTab} onTabChange={handleTabChange} />
        </View>

      </View>
    </View>
  );
}

//================================================================
// 4. STYLES
//================================================================
const styles = StyleSheet.create({
  gradientBlob: {
    position: 'absolute',
    width: SHELL_WIDTH * 1.6,
    height: SHELL_WIDTH * 1.6,
    borderRadius: SHELL_WIDTH * 0.8,
    opacity: 0.42,
  },
  topLeftBlob: {
    top: -ds.spacing.xxxl,
    left: -ds.spacing.xxxl,
    backgroundColor: ds.colors.glowCyan,
  },
  bottomRightBlob: {
    bottom: -ds.spacing.xxxl,
    right: -ds.spacing.xxxl,
    backgroundColor: ds.colors.glowMagenta,
  },
  body: {
    flex: 1,
    backgroundColor: ds.colors.backgroundDeep,
    alignItems: 'center',
    justifyContent: 'center',
    padding: ds.spacing.xl,
  },
  mobileFrame: {
    width: SHELL_WIDTH,
    height: SHELL_HEIGHT,
    backgroundColor: ds.colors.background,
    borderRadius: ds.radius.frame,
    overflow: 'hidden',
    borderWidth: ds.spacing.md,
    borderColor: ds.colors.frameBorder,
    ...Platform.select({
      ios: {
        shadowColor: ds.colors.backgroundDeep,
        shadowOpacity: ds.shadow.modern.opacity,
        shadowRadius: ds.shadow.modern.radius,
        shadowOffset: { width: 0, height: ds.shadow.modern.offsetY },
      },
      android: {
        elevation: 24,
      },
    }),
  },
  backgroundLayer: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 0,
  },
  uiLayer: {
    flex: 1,
    zIndex: 10,
  },
  contentWrapper: {
    flex: 1,
    justifyContent: 'space-between',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: ds.spacing.xxxl,
    paddingHorizontal: ds.spacing.xxl,
    paddingBottom: ds.spacing.xl,
  },
  welcomeContainer: {
    flex: 1,
  },
  welcomeText: {
    fontFamily: ds.typography.family,
    fontSize: ds.typography.size.caption,
    color: ds.colors.textSecondary,
    marginBottom: ds.spacing.xs,
  },
  nameText: {
    fontFamily: ds.typography.family,
    fontSize: ds.typography.size.title,
    fontWeight: ds.typography.weight.semibold,
    color: ds.colors.textPrimary,
  },
  mainContent: {
    paddingHorizontal: ds.spacing.xxl,
    paddingTop: ds.spacing.lg,
    justifyContent: 'flex-end',
    paddingBottom: ds.spacing.xxxl,
  },
  heroSection: {
    gap: ds.spacing.sm,
    marginBottom: ds.spacing.xxl,
  },
  heroKicker: {
    fontFamily: ds.typography.family,
    fontSize: ds.typography.size.caption,
    textTransform: 'uppercase',
    letterSpacing: ds.typography.tracking.wide,
    color: ds.colors.textSecondary,
  },
  heroTitle: {
    fontFamily: ds.typography.family,
    fontSize: ds.typography.size.display,
    fontWeight: ds.typography.weight.bold,
    color: ds.colors.textPrimary,
  },
  heroBody: {
    fontFamily: ds.typography.family,
    fontSize: ds.typography.size.body,
    color: ds.colors.textSecondary,
    lineHeight: ds.typography.lineHeight.body,
  },
  glassCard: {
    borderRadius: ds.radius.lg,
    padding: ds.spacing.xl,
    borderWidth: 1,
    borderColor: ds.colors.borderSubtle,
    marginBottom: ds.spacing.xl,
    transform: [{ perspective: 1200 }],
    ...Platform.select({
      ios: {
        shadowColor: ds.colors.primary,
        shadowOffset: { width: 0, height: ds.shadow.modern.offsetY },
        shadowOpacity: ds.shadow.modern.opacity,
        shadowRadius: ds.shadow.modern.radius,
      },
      android: {
        elevation: 8,
      },
    }),
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    columnGap: ds.spacing.md,
    height: ds.spacing.xxl,
  },
  dotOrigin: {
    width: ds.spacing.sm,
    height: ds.spacing.sm,
    borderRadius: ds.spacing.sm / 2,
    backgroundColor: ds.colors.textSecondary,
  },
  dotDest: {
    width: ds.spacing.sm,
    height: ds.spacing.sm,
    borderRadius: ds.spacing.sm / 2,
    backgroundColor: ds.colors.primary,
    shadowColor: ds.colors.primary,
    shadowOpacity: 0.5,
    shadowRadius: 8,
  },
  divider: {
    height: 1,
    backgroundColor: ds.colors.border,
    marginVertical: ds.spacing.sm,
    marginLeft: ds.spacing.xxl,
  },
  inputText: {
    flex: 1,
    fontFamily: ds.typography.family,
    fontSize: ds.typography.size.body,
    color: ds.colors.textPrimary,
  },
  input: {
    flex: 1,
    fontFamily: ds.typography.family,
    fontSize: ds.typography.size.bodyLg,
    color: ds.colors.textPrimary,
    padding: 0,
    shadowColor: ds.colors.primary,
    shadowOffset: { width: 0, height: ds.shadow.innerGlow.offsetY },
    shadowOpacity: ds.shadow.innerGlow.opacity,
    shadowRadius: ds.shadow.innerGlow.radius,
  },
  errorText: {
    color: ds.colors.danger,
    textAlign: 'center',
    marginBottom: ds.spacing.md,
    fontSize: ds.typography.size.caption,
    fontFamily: ds.typography.family,
  },
  telemetryCard: {
    marginTop: ds.spacing.xxl,
    paddingHorizontal: ds.spacing.xxl,
    paddingVertical: ds.spacing.xl,
    borderRadius: ds.radius.lg,
    gap: ds.spacing.lg,
    backgroundColor: ds.colors.surfaceElevated,
  },
  telemetryTitle: {
    fontFamily: ds.typography.family,
    fontSize: ds.typography.size.caption,
    letterSpacing: ds.typography.tracking.normal,
    color: ds.colors.textSecondary,
    textTransform: 'uppercase',
  },
  telemetryRowGroup: {
    gap: ds.spacing.md,
  },
  telemetryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  telemetryLabel: {
    fontFamily: ds.typography.family,
    fontSize: ds.typography.size.body,
    color: ds.colors.textSecondary,
  },
  telemetryValue: {
    fontFamily: ds.typography.family,
    fontSize: ds.typography.size.body,
    color: ds.colors.textPrimary,
    fontWeight: ds.typography.weight.medium,
  },
  navContainer: {
    position: 'absolute',
    bottom: ds.spacing.xxxl,
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 100,
  },
  // Ride Selection
  bottomSheet: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  sheetContent: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    padding: 24,
    borderTopWidth: 1,
    borderColor: ds.colors.border,
  },
  dragHandle: {
    width: 40,
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 24,
  },
  sheetTitle: {
    fontFamily: ds.typography.family,
    fontSize: 18,
    fontWeight: '600',
    color: ds.colors.textPrimary,
    marginBottom: 20,
  },
  rideList: {
    gap: 12,
    marginBottom: 24,
  },
  rideOption: {
    // Styles handled by AuraCard defaults mostly
  },
  rideOptionSelected: {
    borderColor: ds.colors.primary,
    backgroundColor: 'rgba(0, 245, 255, 0.05)',
  },
  rideOptionInner: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rideIcon: {
    fontSize: 24,
    marginRight: 16,
  },
  rideName: {
    fontFamily: ds.typography.family,
    fontSize: 16,
    fontWeight: '500',
    color: ds.colors.textPrimary,
  },
  rideTime: {
    fontFamily: ds.typography.family,
    fontSize: 12,
    color: ds.colors.textSecondary,
  },
  ridePrice: {
    fontFamily: ds.typography.family,
    fontSize: 16,
    fontWeight: '600',
    color: ds.colors.textPrimary,
  },
  paymentRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
    paddingHorizontal: 4,
  },
  paymentMethod: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardIcon: {
    width: ds.spacing.xl,
    height: ds.spacing.lg,
    backgroundColor: ds.colors.textPrimary,
    borderRadius: ds.radius.xs / 2,
  },
  paymentText: {
    fontFamily: ds.typography.family,
    fontSize: 14,
    color: ds.colors.textPrimary,
  },
  promoText: {
    color: ds.colors.primary,
    fontSize: 14,
    fontWeight: '500',
    fontFamily: ds.typography.family,
  },
});
