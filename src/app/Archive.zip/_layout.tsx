import { Slot } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet } from 'react-native';
import React, { useEffect, useRef, useState } from 'react';
import * as SplashScreen from 'expo-splash-screen';
import * as Font from 'expo-font';
import { Audio } from 'expo-av';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { Poppins_400Regular, Poppins_500Medium, Poppins_700Bold } from '@expo-google-fonts/poppins';

import { ds } from '../constants/theme';
import { NoiseOverlay } from '../components/ui/NoiseOverlay';
import { SoundProvider, SoundRegistry, SoundEffect } from '../hooks/useSound';
import '../i18n';

const SOUND_SOURCES: Record<SoundEffect, number> = {
  click: require('../../assets/sounds/click.wav'),
  power: require('../../assets/sounds/power.wav'),
};

SplashScreen.preventAutoHideAsync().catch(() => {
  // no-op if splash already hidden
});

const loadSoundRegistry = async (): Promise<SoundRegistry> => {
  const entries = await Promise.all(
    (Object.keys(SOUND_SOURCES) as SoundEffect[]).map(async (effect) => {
      const sound = new Audio.Sound();
      await sound.loadAsync(SOUND_SOURCES[effect]);
      return [effect, sound] as const;
    })
  );
  return Object.fromEntries(entries) as SoundRegistry;
};

const unloadSoundRegistry = async (registry: SoundRegistry | null) => {
  if (!registry) return;
  await Promise.all(
    Object.values(registry).map(async (sound) => {
      try {
        await sound.unloadAsync();
      } catch {
        // ignore unload errors
      }
    })
  );
};

export default function RootLayout() {
  const [ready, setReady] = useState(false);
  const [registry, setRegistry] = useState<SoundRegistry | null>(null);
  const registryRef = useRef<SoundRegistry | null>(null);

  useEffect(() => {
    let isActive = true;

    const prepare = async () => {
      try {
        await Font.loadAsync({
          Poppins_400Regular,
          Poppins_500Medium,
          Poppins_700Bold,
        });
        const loadedRegistry = await loadSoundRegistry();

        if (!isActive) {
          await unloadSoundRegistry(loadedRegistry);
          return;
        }

        registryRef.current = loadedRegistry;
        setRegistry(loadedRegistry);
        setReady(true);
      } catch (error) {
        console.error('Bootstrap error', error);
      } finally {
        if (isActive) {
          await SplashScreen.hideAsync();
        }
      }
    };

    prepare();

    return () => {
      isActive = false;
      const snapshot = registryRef.current;
      registryRef.current = null;
      unloadSoundRegistry(snapshot);
    };
  }, []);

  if (!ready || !registry) {
    return null;
  }

  return (
    <GestureHandlerRootView style={styles.root}>
      <SoundProvider registry={registry}>
        <StatusBar style="light" translucent backgroundColor="transparent" />
        <Slot />
        <NoiseOverlay />
      </SoundProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: ds.colors.background,
  },
});
