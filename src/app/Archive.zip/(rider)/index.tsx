import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { SafeAreaView, StyleSheet, Text, View } from 'react-native';
import Animated, {
  Easing,
  FadeInDown,
  runOnJS,
  useAnimatedSensor,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
  SensorType,
} from 'react-native-reanimated';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';

import { ds } from '../../constants/theme';
import { GlassView } from '../../components/ui/GlassView';
import { AccentLine } from '../../components/ui/AccentLine';
import { Icon } from '../../components/ui/Icon';
import { Globe, GlobeHandle, GlobePerformanceSample } from '../../components/3d/Globe';
import { MapContainer, MapContainerHandle } from '../../components/map/MapContainer';
import { useSound } from '../../hooks/useSound';
import { useHaptics } from '../../hooks/useHaptics';
import { DestinationInput, DestinationInputHandle } from '../../components/ui/DestinationInput';
import { rideOptions, destinationPresets, RideOptionId, DestinationPreset } from '../../constants/rides';
import { RideOptionCard } from '../../components/ui/RideOptionCard';
import { NeonButton } from '../../components/ui/NeonButton';
import { FloatingTabBar, TabId } from '../../components/ui/FloatingTabBar';
import { useStore } from '../../context/Store';

const entranceEasing = Easing.bezier(0.22, 1, 0.36, 1);
const crossFadeInEasing = Easing.bezier(...ds.motion.easing.entrance);
const crossFadeOutEasing = Easing.bezier(...ds.motion.easing.exit);
const CTA_COORDINATE: [number, number] = [-74.006, 40.7128];
const MAP_DEFAULTS = {
  zoomLevel: 13.2,
  pitch: 62,
  heading: 24,
};

const DESTINATION_INPUT_HINT = 'Enter your desired drop-off';
const DESTINATION_PRESET_HINT = 'Double tap to set this as your destination';
const CONFIRM_RIDE_HINT = 'Double tap to request this ride';

const describeRideOption = (id: RideOptionId) => {
  switch (id) {
    case 'lux':
      return {
        name: 'Aura Lux',
        description: 'BMW i7 · Private · 2 pax',
        eta: 'ETA · 3 min',
        price: '€42',
      };
    case 'pulse':
      return {
        name: 'Aura Pulse',
        description: 'Polestar 4 · Performance tuned',
        eta: 'ETA · 4 min',
        price: '€36',
      };
    case 'share':
    default:
      return {
        name: 'Aura Share',
        description: 'Audi Q4 e-tron · Carpool',
        eta: 'ETA · 6 min',
        price: '€18',
      };
  }
};

const describeDestinationLabel = (id: DestinationPreset['id']) => {
  switch (id) {
    case 'vibeDistrict':
      return 'Neon Vibe District';
    case 'equinoxHub':
      return 'Equinox Transfer Hub';
    case 'skyGarden':
    default:
      return 'Sky Garden Terminal';
  }
};

interface DestinationPillProps {
  label: string;
  delay: number;
  onPress: () => void;
  accessibilityHint?: string;
}

const DestinationPillComponent = ({ label, delay, onPress, accessibilityHint }: DestinationPillProps) => {
  const press = useSharedValue(0);

  const gesture = useMemo(
    () =>
      Gesture.Tap()
        .onBegin(() => {
          press.value = withTiming(1, {
            duration: ds.motion.duration.micro,
            easing: Easing.bezier(...ds.motion.easing.micro),
          });
        })
        .onFinalize(() => {
          press.value = withTiming(0, {
            duration: ds.motion.duration.exit,
            easing: Easing.bezier(...ds.motion.easing.exit),
          });
        })
        .onEnd(() => {
          onPress();
        }),
    [onPress, press]
  );

  const containerStyle = useAnimatedStyle(() => ({
    backgroundColor: press.value > 0.5 ? ds.colors.surfaceElevated : ds.colors.surface,
    shadowColor: ds.colors.primary,
    shadowOpacity: press.value * 0.25,
    shadowRadius: ds.shadow.soft.radius + press.value * 6,
    transform: [{ scale: 1 - press.value * 0.04 }],
  }));

  return (
    <GestureDetector gesture={gesture}>
      <Animated.View
        entering={FadeInDown.duration(ds.motion.duration.entrance).delay(delay)}
        style={[styles.recentPill, containerStyle]}
        accessibilityRole="button"
        accessibilityLabel={label}
        accessibilityHint={accessibilityHint}
      >
        <Text style={styles.recentPillLabel}>{label}</Text>
      </Animated.View>
    </GestureDetector>
  );
};

const DestinationPill = React.memo(
  DestinationPillComponent,
  (prev, next) =>
    prev.label === next.label &&
    prev.delay === next.delay &&
    prev.onPress === next.onPress &&
    prev.accessibilityHint === next.accessibilityHint
);

export default function RiderHome() {
  const { play } = useSound();
  const { trigger } = useHaptics();
  const destinationInputRef = useRef<DestinationInputHandle>(null);
  const destinationQuery = useStore((state) => state.destinationQuery);
  const setDestinationQuery = useStore((state) => state.setDestinationQuery);
  const selectedRideOptionId = useStore((state) => state.selectedRideOptionId);
  const setSelectedRideOption = useStore((state) => state.setSelectedRideOption);
  const globeRef = useRef<GlobeHandle>(null);
  const mapRef = useRef<MapContainerHandle>(null);
  const sampleWindowRef = useRef<GlobePerformanceSample[]>([]);
  const heapStatsRef = useRef<{ min?: number; max?: number }>({});
  const targetCoordinateRef = useRef<[number, number]>(CTA_COORDINATE);
  const pendingRevealRef = useRef(false);
  const gyro = useAnimatedSensor(SensorType.GYROSCOPE);
  const entrance = useSharedValue(0);
  const sweep = useSharedValue(-140);
  const mapOpacity = useSharedValue(0);
  const globeOpacity = useSharedValue(1);
  const [globeSample, setGlobeSample] = useState<GlobePerformanceSample | null>(null);
  const [fpsBaseline, setFpsBaseline] = useState<number | null>(null);
  const [heapVariance, setHeapVariance] = useState<number | null>(null);
  const [mapCoordinate, setMapCoordinate] = useState<[number, number]>(CTA_COORDINATE);
  const [mapReady, setMapReady] = useState(false);
  const [mapInteractive, setMapInteractive] = useState(false);
  const [activeTab, setActiveTab] = useState<TabId>('home');
  const [listMountFrameBudget, setListMountFrameBudget] = useState<number | null>(null);
  const listMountPerfRef = useRef<{ active: boolean; start: number; maxFrame: number; timeout: ReturnType<typeof setTimeout> | null }>(
    {
      active: false,
      start: 0,
      maxFrame: 0,
      timeout: null,
    }
  );

  useEffect(() => {
    if (!selectedRideOptionId) {
      setSelectedRideOption('lux');
    }
  }, [selectedRideOptionId, setSelectedRideOption]);

  useEffect(() => {
    entrance.value = withTiming(1, { duration: 650, easing: entranceEasing });
    sweep.value = withRepeat(withTiming(140, { duration: 4200, easing: Easing.linear }), -1, false);
  }, [entrance, sweep]);

  useEffect(() => {
    const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
    const ref = listMountPerfRef.current;
    if (ref.timeout) {
      clearTimeout(ref.timeout);
    }
    ref.active = true;
    ref.start = now;
    ref.maxFrame = 0;
    ref.timeout = setTimeout(() => {
      setListMountFrameBudget(ref.maxFrame);
      ref.active = false;
      ref.timeout = null;
    }, 1200);

    return () => {
      if (ref.timeout) {
        clearTimeout(ref.timeout);
        ref.timeout = null;
      }
      ref.active = false;
    };
  }, []);

  const rideOptionCards = useMemo(
    () =>
      rideOptions.map((option) => {
        const base = describeRideOption(option.id);
        const surgeLabel =
          option.surgeMultiplier != null
            ? `Surge x${option.surgeMultiplier.toFixed(1)}`
            : undefined;
        const labelParts = [base.name, base.description, base.eta, base.price];
        if (surgeLabel) {
          labelParts.push(surgeLabel);
        }
        return {
          option,
          name: base.name,
          description: base.description,
          eta: base.eta,
          price: base.price,
          surgeLabel,
          accessibilityLabel: labelParts.join('. '),
        };
      }),
    []
  );

  const recentDestinationItems = useMemo(
    () =>
      destinationPresets.map((preset, index) => ({
        preset,
        label: describeDestinationLabel(preset.id),
        delay: index * 40,
      })),
    []
  );

  const startZoomToCoordinate = (coordinate: [number, number], radius = 2.1) => {
    pendingRevealRef.current = true;
    targetCoordinateRef.current = coordinate;
    setMapCoordinate(coordinate);
    setMapInteractive(false);
    globeOpacity.value = 1;
    mapOpacity.value = 0;
    globeRef.current?.zoomToLocation({ lat: coordinate[1], lon: coordinate[0], radius });
  };

  const handleDestinationPresetPress = (preset: DestinationPreset) => {
    trigger('selection');
    play('click');
    const label = describeDestinationLabel(preset.id);
    setDestinationQuery(label);
    destinationInputRef.current?.blur();
    startZoomToCoordinate(preset.coordinate, preset.radius ?? 2);
  };

  const handleDestinationFocus = () => {
    trigger('selection');
    play('click');
  };

  const handleRideOptionPress = (optionId: RideOptionId) => {
    setSelectedRideOption(optionId);
  };

  const handleConfirmRide = () => {
    startZoomToCoordinate(targetCoordinateRef.current, 2.1);
  };

  const handleDestinationSubmit = () => {
    handleConfirmRide();
  };

  const handleZoomStart = () => {
    trigger('heavy');
    play('power');
    pendingRevealRef.current = true;
    setMapInteractive(false);
    globeOpacity.value = 1;
    mapOpacity.value = 0;
  };

  const handlePerformanceSample = useCallback((sample: GlobePerformanceSample) => {
    setGlobeSample(sample);
    sampleWindowRef.current = [...sampleWindowRef.current.slice(-5), sample];
    if (sampleWindowRef.current.length >= 3) {
      const avgFps =
        sampleWindowRef.current.reduce((total, item) => total + item.fps, 0) /
        sampleWindowRef.current.length;
      setFpsBaseline(avgFps);
    }

    if (sample.heapSizeBytes != null) {
      const stats = heapStatsRef.current;
      stats.min = stats.min === undefined ? sample.heapSizeBytes : Math.min(stats.min, sample.heapSizeBytes);
      stats.max = stats.max === undefined ? sample.heapSizeBytes : Math.max(stats.max, sample.heapSizeBytes);
      const drift = stats.max - stats.min;
      setHeapVariance(drift);
    }

    const listPerf = listMountPerfRef.current;
    if (listPerf.active) {
      listPerf.maxFrame = Math.max(listPerf.maxFrame, sample.frameTimeMs);
      const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
      if (now - listPerf.start > 1200) {
        if (listPerf.timeout) {
          clearTimeout(listPerf.timeout);
          listPerf.timeout = null;
        }
        listPerf.active = false;
        setListMountFrameBudget(listPerf.maxFrame);
      }
    }
  }, []);

  const beginMapReveal = () => {
    const coordinate = targetCoordinateRef.current;
    pendingRevealRef.current = false;
    mapRef.current?.focusTo({
      coordinate,
      zoomLevel: MAP_DEFAULTS.zoomLevel,
      pitch: MAP_DEFAULTS.pitch,
      heading: MAP_DEFAULTS.heading,
      durationMs: 1100,
    });

    globeOpacity.value = withTiming(0, {
      duration: ds.motion.duration.crossFade,
      easing: crossFadeOutEasing,
    });

    mapOpacity.value = withTiming(
      1,
      {
        duration: ds.motion.duration.crossFade,
        easing: crossFadeInEasing,
      },
      (finished) => {
        if (finished) {
          runOnJS(setMapInteractive)(true);
        }
      }
    );
  };

  const handleZoomComplete = () => {
    if (!mapReady) {
      pendingRevealRef.current = true;
      return;
    }
    beginMapReveal();
  };

  const handleMapReady = () => {
    if (!mapReady) {
      setMapReady(true);
    }
    if (pendingRevealRef.current) {
      beginMapReveal();
    }
  };

  const handleTabChange = (tab: TabId) => {
    setActiveTab(tab);
  };

  const heroStyle = useAnimatedStyle(() => ({
    opacity: entrance.value,
    transform: [
      { translateY: (1 - entrance.value) * 32 },
      { scale: 0.9 + entrance.value * 0.1 },
    ],
  }));

  const backgroundStyle = useAnimatedStyle(() => ({
    opacity: entrance.value,
    transform: [
      { translateY: (1 - entrance.value) * 24 },
      { scale: 0.92 + entrance.value * 0.08 },
    ],
  }));

  const sweepStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: sweep.value }],
  }));

  const parallaxStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: gyro.sensor.value.y * 8 },
      { translateY: gyro.sensor.value.x * -6 },
    ],
  }));

  const mapOpacityStyle = useAnimatedStyle(() => ({
    opacity: mapOpacity.value,
  }));

  const globeOpacityStyle = useAnimatedStyle(() => ({
    opacity: globeOpacity.value,
  }));

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <Animated.View
          pointerEvents={mapInteractive ? 'auto' : 'none'}
          style={[styles.mapLayer, backgroundStyle, parallaxStyle, mapOpacityStyle]}
        >
          <MapContainer
            ref={mapRef}
            coordinate={mapCoordinate}
            zoomLevel={MAP_DEFAULTS.zoomLevel}
            pitch={MAP_DEFAULTS.pitch}
            heading={MAP_DEFAULTS.heading}
            style={styles.mapFrame}
            onMapReady={handleMapReady}
          />
        </Animated.View>
        <Animated.View pointerEvents="none" style={[styles.globeLayer, backgroundStyle, parallaxStyle, globeOpacityStyle]}>
          <Globe
            ref={globeRef}
            height={360}
            rotationSpeed={0.08}
            onZoomStart={handleZoomStart}
            onZoomComplete={handleZoomComplete}
            onPerformanceSample={handlePerformanceSample}
          />
        </Animated.View>
        <Animated.View style={[styles.heroBackdrop, heroStyle, parallaxStyle]}>
          <Animated.View pointerEvents="none" style={[styles.lightSweep, sweepStyle]} />
          <GlassView style={styles.primaryCard}>
            <View style={styles.primaryContent}>
              <View style={styles.headerBlock}>
                <AccentLine height={8} />
                <Text style={styles.kicker}>Phase 01</Text>
                <Text style={styles.title}>Premium Shell Online</Text>
                <Text style={styles.body}>
                  Fonts, glass, and ambience are locked. Next up: cinematic motion + ride entrypoints.
                </Text>
              </View>

              <DestinationInput
                ref={destinationInputRef}
                label="Destination"
                placeholder="Where do you want to go?"
                value={destinationQuery}
                onChangeText={setDestinationQuery}
                onSubmitEditing={() => handleDestinationSubmit()}
                onFocus={handleDestinationFocus}
                returnKeyType="search"
                accessibilityHint={DESTINATION_INPUT_HINT}
              />

              <View style={styles.recentBlock}>
                <Text style={styles.sectionTitle}>Recent drops</Text>
                <View style={styles.recentPillsRow}>
                  {recentDestinationItems.map(({ preset, label, delay }) => (
                    <DestinationPill
                      key={preset.id}
                      label={label}
                      delay={delay}
                      onPress={() => handleDestinationPresetPress(preset)}
                      accessibilityHint={DESTINATION_PRESET_HINT}
                    />
                  ))}
                </View>
              </View>

              <View style={styles.optionsHeader}>
                <Text style={styles.sectionTitle}>Choose your aura</Text>
                <Text style={styles.sectionSubtitle}>Every tier tuned for the city pulse.</Text>
              </View>

              <View style={styles.optionsList}>
                {rideOptionCards.map(({ option, name, description, eta, price, surgeLabel, accessibilityLabel }) => {
                  const isSelected = selectedRideOptionId === option.id;
                  const hint = isSelected
                    ? 'Selected ride tier'
                    : 'Double tap to choose this ride tier';
                  const label = isSelected
                    ? `${accessibilityLabel}. Selected ride tier`
                    : accessibilityLabel;

                  return (
                    <RideOptionCard
                      key={option.id}
                      config={option}
                      name={name}
                      description={description}
                      eta={eta}
                      price={price}
                      surgeLabel={surgeLabel}
                      selected={isSelected}
                      onPress={() => handleRideOptionPress(option.id)}
                      accessibilityLabel={label}
                      accessibilityHint={hint}
                    />
                  );
                })}
              </View>

              <NeonButton
                onPress={handleConfirmRide}
                soundEffect="power"
                hapticPattern="success"
                style={styles.requestButton}
                accessibilityHint={CONFIRM_RIDE_HINT}
              >
                Request Ride
              </NeonButton>
            </View>
          </GlassView>

          <View style={styles.heroSpacer} />

          <GlassView style={styles.secondaryCard}>
            <View style={styles.secondaryContent}>
              <Text style={[styles.secondaryTitle, styles.sectionSpacingSmall]}>Telemetry</Text>
              <View style={[styles.metricRow, styles.sectionSpacingSmall]}>
                <Text style={styles.metricLabel}>FPS Avg</Text>
                <Text style={styles.metricValue}>
                  {fpsBaseline != null ? fpsBaseline.toFixed(1) : globeSample ? globeSample.fps.toFixed(1) : '—'}
                </Text>
              </View>
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>Frame Time</Text>
                <Text style={styles.metricValue}>
                  {globeSample ? `${globeSample.frameTimeMs.toFixed(1)} ms` : '—'}
                </Text>
              </View>
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>Heap Drift</Text>
                <Text style={styles.metricValue}>
                  {heapVariance != null
                    ? `${(heapVariance / (1024 * 1024)).toFixed(2)} MB`
                    : globeSample?.heapSizeBytes
                    ? `${(globeSample.heapSizeBytes / (1024 * 1024)).toFixed(2)} MB`
                    : '—'}
                </Text>
              </View>
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>List Mount Frame</Text>
                <Text style={styles.metricValue}>
                  {listMountFrameBudget != null ? `${listMountFrameBudget.toFixed(1)} ms` : '—'}
                </Text>
              </View>
              <View style={[styles.metricRow, { alignItems: 'center' }]}>
                <Text style={styles.metricLabel}>Sensors</Text>
                <Icon name="activity" size={16} color={ds.colors.primary} active />
              </View>
            </View>
          </GlassView>
        </Animated.View>
        <View style={styles.tabBarContainer} pointerEvents="box-none">
          <FloatingTabBar activeTab={activeTab} onTabChange={handleTabChange} />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: ds.colors.background,
  },
  container: {
    flex: 1,
    paddingHorizontal: ds.spacing.xl,
    paddingVertical: ds.spacing.xl,
    justifyContent: 'center',
    paddingBottom: ds.spacing.xxl,
  },
  heroBackdrop: {
    borderRadius: ds.radius.xl,
    padding: ds.spacing.xl,
    overflow: 'hidden',
  },
  mapLayer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapFrame: {
    width: '100%',
    height: 360,
  },
  globeLayer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  lightSweep: {
    position: 'absolute',
    top: 0,
    left: -200,
    width: 160,
    height: '100%',
    backgroundColor: ds.colors.primary,
    opacity: 0.12,
    borderRadius: ds.radius.lg,
  },
  primaryCard: {
    padding: 0,
  },
  primaryContent: {
    paddingHorizontal: ds.spacing.lg,
    paddingVertical: ds.spacing.lg,
    gap: ds.spacing.lg,
  },
  secondaryCard: {
    padding: 0,
  },
  secondaryContent: {
    paddingHorizontal: ds.spacing.lg,
    paddingVertical: ds.spacing.md,
  },
  heroSpacer: {
    height: ds.spacing.xl,
  },
  sectionSpacingSmall: {
    marginBottom: ds.spacing.sm,
  },
  headerBlock: {
    gap: ds.spacing.sm,
  },
  kicker: {
    color: ds.colors.textMuted,
    fontFamily: ds.typography.family,
    fontWeight: ds.typography.weight.medium,
    letterSpacing: 2,
    textTransform: 'uppercase',
  },
  title: {
    color: ds.colors.text,
    fontFamily: ds.typography.family,
    fontWeight: ds.typography.weight.bold,
    fontSize: 36,
    lineHeight: 40,
  },
  body: {
    color: ds.colors.textMuted,
    fontFamily: ds.typography.family,
    fontWeight: ds.typography.weight.regular,
    fontSize: 16,
    lineHeight: 24,
  },
  sectionTitle: {
    color: ds.colors.text,
    fontFamily: ds.typography.family,
    fontWeight: ds.typography.weight.semibold,
    fontSize: ds.typography.size.bodyLg,
    letterSpacing: 0.6,
    textTransform: 'uppercase',
  },
  sectionSubtitle: {
    color: ds.colors.textSecondary,
    fontFamily: ds.typography.family,
    fontWeight: ds.typography.weight.regular,
    fontSize: ds.typography.size.body,
  },
  recentBlock: {
    gap: ds.spacing.sm,
  },
  recentPillsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: ds.spacing.sm,
  },
  recentPill: {
    paddingVertical: ds.spacing.xs,
    paddingHorizontal: ds.spacing.md,
    borderRadius: ds.radius.md,
    borderWidth: 1,
    borderColor: ds.colors.outlineSubtle,
    backgroundColor: ds.colors.surface,
  },
  recentPillLabel: {
    fontFamily: ds.typography.family,
    fontSize: ds.typography.size.body,
    fontWeight: ds.typography.weight.medium,
    color: ds.colors.textPrimary,
    letterSpacing: 0.4,
  },
  optionsHeader: {
    gap: ds.spacing.xs,
    marginTop: ds.spacing.lg,
  },
  optionsList: {
    gap: ds.spacing.md,
  },
  requestButton: {
    alignSelf: 'flex-start',
    marginTop: ds.spacing.lg,
  },
  secondaryTitle: {
    color: ds.colors.text,
    fontFamily: ds.typography.family,
    fontWeight: ds.typography.weight.medium,
    fontSize: 18,
  },
  metricRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  metricLabel: {
    color: ds.colors.textMuted,
    fontFamily: ds.typography.family,
    fontWeight: ds.typography.weight.regular,
  },
  metricValue: {
    color: ds.colors.primary,
    fontFamily: ds.typography.family,
    fontWeight: ds.typography.weight.bold,
  },
  tabBarContainer: {
    position: 'absolute',
    left: ds.spacing.xl,
    right: ds.spacing.xl,
    bottom: ds.spacing.xl,
  },
});
